# Cliente-Web-Services-PHP
Cómo implementar un cliente y consumir un servicio Web (Web Services) SOAP en PHP
